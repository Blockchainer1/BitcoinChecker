package android.support.v7.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();
  
  public abstract void onActionViewExpanded();
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/android/support/v7/view/CollapsibleActionView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */