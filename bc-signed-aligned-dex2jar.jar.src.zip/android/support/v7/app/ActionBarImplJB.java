package android.support.v7.app;

import android.app.Activity;

public class ActionBarImplJB
  extends ActionBarImplICS
{
  public ActionBarImplJB(Activity paramActivity, ActionBar.Callback paramCallback)
  {
    super(paramActivity, paramCallback, false);
  }
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/android/support/v7/app/ActionBarImplJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */