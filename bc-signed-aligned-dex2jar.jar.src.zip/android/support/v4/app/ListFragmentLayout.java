package android.support.v4.app;

import android.view.View;

public class ListFragmentLayout
{
  public static void setupIds(View paramView)
  {
    paramView.findViewById(2131624054).setId(16711681);
    paramView.findViewById(2131624052).setId(16711682);
    paramView.findViewById(2131624053).setId(16711683);
  }
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/android/support/v4/app/ListFragmentLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */