package android.support.v4.provider;

import android.content.Context;
import android.net.Uri;
import android.os.Build.VERSION;
import java.io.File;

public abstract class DocumentFile
{
  static final String TAG = "DocumentFile";
  private final DocumentFile mParent;
  
  DocumentFile(DocumentFile paramDocumentFile)
  {
    this.mParent = paramDocumentFile;
  }
  
  public static DocumentFile fromFile(File paramFile)
  {
    return new RawDocumentFile(null, paramFile);
  }
  
  public static DocumentFile fromSingleUri(Context paramContext, Uri paramUri)
  {
    if (Build.VERSION.SDK_INT >= 19) {}
    for (paramContext = new SingleDocumentFile(null, paramContext, paramUri);; paramContext = null) {
      return paramContext;
    }
  }
  
  public static DocumentFile fromTreeUri(Context paramContext, Uri paramUri)
  {
    if (Build.VERSION.SDK_INT >= 21) {}
    for (paramContext = new TreeDocumentFile(null, paramContext, DocumentsContractApi21.prepareTreeUri(paramUri));; paramContext = null) {
      return paramContext;
    }
  }
  
  public static boolean isDocumentUri(Context paramContext, Uri paramUri)
  {
    if (Build.VERSION.SDK_INT >= 19) {}
    for (boolean bool = DocumentsContractApi19.isDocumentUri(paramContext, paramUri);; bool = false) {
      return bool;
    }
  }
  
  public abstract boolean canRead();
  
  public abstract boolean canWrite();
  
  public abstract DocumentFile createDirectory(String paramString);
  
  public abstract DocumentFile createFile(String paramString1, String paramString2);
  
  public abstract boolean delete();
  
  public abstract boolean exists();
  
  public DocumentFile findFile(String paramString)
  {
    DocumentFile[] arrayOfDocumentFile = listFiles();
    int i = arrayOfDocumentFile.length;
    int j = 0;
    DocumentFile localDocumentFile;
    if (j < i)
    {
      localDocumentFile = arrayOfDocumentFile[j];
      if (!paramString.equals(localDocumentFile.getName())) {}
    }
    for (paramString = localDocumentFile;; paramString = null)
    {
      return paramString;
      j++;
      break;
    }
  }
  
  public abstract String getName();
  
  public DocumentFile getParentFile()
  {
    return this.mParent;
  }
  
  public abstract String getType();
  
  public abstract Uri getUri();
  
  public abstract boolean isDirectory();
  
  public abstract boolean isFile();
  
  public abstract long lastModified();
  
  public abstract long length();
  
  public abstract DocumentFile[] listFiles();
  
  public abstract boolean renameTo(String paramString);
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/android/support/v4/provider/DocumentFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */