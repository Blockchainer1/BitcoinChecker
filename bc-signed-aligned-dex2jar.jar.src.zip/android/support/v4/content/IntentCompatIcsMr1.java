package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1
{
  public static Intent makeMainSelectorActivity(String paramString1, String paramString2)
  {
    return Intent.makeMainSelectorActivity(paramString1, paramString2);
  }
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/android/support/v4/content/IntentCompatIcsMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */