package com.google.gson.internal;

public abstract interface ObjectConstructor<T>
{
  public abstract T construct();
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/com/google/gson/internal/ObjectConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */