package com.android.volley.toolbox;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public class ImageLoader
{
  private int mBatchResponseDelayMs = 100;
  private final HashMap<String, BatchedImageRequest> mBatchedResponses = new HashMap();
  private final ImageCache mCache;
  private final Handler mHandler = new Handler(Looper.getMainLooper());
  private final HashMap<String, BatchedImageRequest> mInFlightRequests = new HashMap();
  private final RequestQueue mRequestQueue;
  private Runnable mRunnable;
  
  public ImageLoader(RequestQueue paramRequestQueue, ImageCache paramImageCache)
  {
    this.mRequestQueue = paramRequestQueue;
    this.mCache = paramImageCache;
  }
  
  private void batchResponse(String paramString, BatchedImageRequest paramBatchedImageRequest)
  {
    this.mBatchedResponses.put(paramString, paramBatchedImageRequest);
    if (this.mRunnable == null)
    {
      this.mRunnable = new Runnable()
      {
        public void run()
        {
          Iterator localIterator1 = ImageLoader.this.mBatchedResponses.values().iterator();
          for (;;)
          {
            if (!localIterator1.hasNext())
            {
              ImageLoader.this.mBatchedResponses.clear();
              ImageLoader.this.mRunnable = null;
              return;
            }
            ImageLoader.BatchedImageRequest localBatchedImageRequest = (ImageLoader.BatchedImageRequest)localIterator1.next();
            Iterator localIterator2 = ImageLoader.BatchedImageRequest.access$0(localBatchedImageRequest).iterator();
            while (localIterator2.hasNext())
            {
              ImageLoader.ImageContainer localImageContainer = (ImageLoader.ImageContainer)localIterator2.next();
              if (ImageLoader.ImageContainer.access$0(localImageContainer) != null) {
                if (localBatchedImageRequest.getError() == null)
                {
                  ImageLoader.ImageContainer.access$1(localImageContainer, ImageLoader.BatchedImageRequest.access$2(localBatchedImageRequest));
                  ImageLoader.ImageContainer.access$0(localImageContainer).onResponse(localImageContainer, false);
                }
                else
                {
                  ImageLoader.ImageContainer.access$0(localImageContainer).onErrorResponse(localBatchedImageRequest.getError());
                }
              }
            }
          }
        }
      };
      this.mHandler.postDelayed(this.mRunnable, this.mBatchResponseDelayMs);
    }
  }
  
  private static String getCacheKey(String paramString, int paramInt1, int paramInt2)
  {
    return paramString.length() + 12 + "#W" + paramInt1 + "#H" + paramInt2 + paramString;
  }
  
  public static ImageListener getImageListener(final ImageView paramImageView, final int paramInt1, int paramInt2)
  {
    new ImageListener()
    {
      public void onErrorResponse(VolleyError paramAnonymousVolleyError)
      {
        if (this.val$errorImageResId != 0) {
          paramImageView.setImageResource(this.val$errorImageResId);
        }
      }
      
      public void onResponse(ImageLoader.ImageContainer paramAnonymousImageContainer, boolean paramAnonymousBoolean)
      {
        if (paramAnonymousImageContainer.getBitmap() != null) {
          paramImageView.setImageBitmap(paramAnonymousImageContainer.getBitmap());
        }
        for (;;)
        {
          return;
          if (paramInt1 != 0) {
            paramImageView.setImageResource(paramInt1);
          }
        }
      }
    };
  }
  
  private void onGetImageError(String paramString, VolleyError paramVolleyError)
  {
    BatchedImageRequest localBatchedImageRequest = (BatchedImageRequest)this.mInFlightRequests.remove(paramString);
    localBatchedImageRequest.setError(paramVolleyError);
    if (localBatchedImageRequest != null) {
      batchResponse(paramString, localBatchedImageRequest);
    }
  }
  
  private void onGetImageSuccess(String paramString, Bitmap paramBitmap)
  {
    this.mCache.putBitmap(paramString, paramBitmap);
    BatchedImageRequest localBatchedImageRequest = (BatchedImageRequest)this.mInFlightRequests.remove(paramString);
    if (localBatchedImageRequest != null)
    {
      localBatchedImageRequest.mResponseBitmap = paramBitmap;
      batchResponse(paramString, localBatchedImageRequest);
    }
  }
  
  private void throwIfNotOnMainThread()
  {
    if (Looper.myLooper() != Looper.getMainLooper()) {
      throw new IllegalStateException("ImageLoader must be invoked from the main thread.");
    }
  }
  
  public ImageContainer get(String paramString, ImageListener paramImageListener)
  {
    return get(paramString, paramImageListener, 0, 0);
  }
  
  public ImageContainer get(String paramString, ImageListener paramImageListener, int paramInt1, int paramInt2)
  {
    throwIfNotOnMainThread();
    final String str = getCacheKey(paramString, paramInt1, paramInt2);
    Object localObject = this.mCache.getBitmap(str);
    if (localObject != null)
    {
      paramString = new ImageContainer((Bitmap)localObject, paramString, null, null);
      paramImageListener.onResponse(paramString, true);
    }
    for (;;)
    {
      return paramString;
      localObject = new ImageContainer(null, paramString, str, paramImageListener);
      paramImageListener.onResponse((ImageContainer)localObject, true);
      paramImageListener = (BatchedImageRequest)this.mInFlightRequests.get(str);
      if (paramImageListener != null)
      {
        paramImageListener.addContainer((ImageContainer)localObject);
        paramString = (String)localObject;
      }
      else
      {
        paramString = new ImageRequest(paramString, new Response.Listener()
        {
          public void onResponse(Bitmap paramAnonymousBitmap)
          {
            ImageLoader.this.onGetImageSuccess(str, paramAnonymousBitmap);
          }
        }, paramInt1, paramInt2, Bitmap.Config.RGB_565, new Response.ErrorListener()
        {
          public void onErrorResponse(VolleyError paramAnonymousVolleyError)
          {
            ImageLoader.this.onGetImageError(str, paramAnonymousVolleyError);
          }
        });
        this.mRequestQueue.add(paramString);
        this.mInFlightRequests.put(str, new BatchedImageRequest(paramString, (ImageContainer)localObject));
        paramString = (String)localObject;
      }
    }
  }
  
  public boolean isCached(String paramString, int paramInt1, int paramInt2)
  {
    throwIfNotOnMainThread();
    paramString = getCacheKey(paramString, paramInt1, paramInt2);
    if (this.mCache.getBitmap(paramString) != null) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public void setBatchedResponseDelay(int paramInt)
  {
    this.mBatchResponseDelayMs = paramInt;
  }
  
  private class BatchedImageRequest
  {
    private final LinkedList<ImageLoader.ImageContainer> mContainers = new LinkedList();
    private VolleyError mError;
    private final Request<?> mRequest;
    private Bitmap mResponseBitmap;
    
    public BatchedImageRequest(ImageLoader.ImageContainer paramImageContainer)
    {
      this.mRequest = paramImageContainer;
      Object localObject;
      this.mContainers.add(localObject);
    }
    
    public void addContainer(ImageLoader.ImageContainer paramImageContainer)
    {
      this.mContainers.add(paramImageContainer);
    }
    
    public VolleyError getError()
    {
      return this.mError;
    }
    
    public boolean removeContainerAndCancelIfNecessary(ImageLoader.ImageContainer paramImageContainer)
    {
      this.mContainers.remove(paramImageContainer);
      if (this.mContainers.size() == 0) {
        this.mRequest.cancel();
      }
      for (boolean bool = true;; bool = false) {
        return bool;
      }
    }
    
    public void setError(VolleyError paramVolleyError)
    {
      this.mError = paramVolleyError;
    }
  }
  
  public static abstract interface ImageCache
  {
    public abstract Bitmap getBitmap(String paramString);
    
    public abstract void putBitmap(String paramString, Bitmap paramBitmap);
  }
  
  public class ImageContainer
  {
    private Bitmap mBitmap;
    private final String mCacheKey;
    private final ImageLoader.ImageListener mListener;
    private final String mRequestUrl;
    
    public ImageContainer(Bitmap paramBitmap, String paramString1, String paramString2, ImageLoader.ImageListener paramImageListener)
    {
      this.mBitmap = paramBitmap;
      this.mRequestUrl = paramString1;
      this.mCacheKey = paramString2;
      this.mListener = paramImageListener;
    }
    
    public void cancelRequest()
    {
      if (this.mListener == null) {}
      for (;;)
      {
        return;
        ImageLoader.BatchedImageRequest localBatchedImageRequest = (ImageLoader.BatchedImageRequest)ImageLoader.this.mInFlightRequests.get(this.mCacheKey);
        if (localBatchedImageRequest != null)
        {
          if (localBatchedImageRequest.removeContainerAndCancelIfNecessary(this)) {
            ImageLoader.this.mInFlightRequests.remove(this.mCacheKey);
          }
        }
        else
        {
          localBatchedImageRequest = (ImageLoader.BatchedImageRequest)ImageLoader.this.mBatchedResponses.get(this.mCacheKey);
          if (localBatchedImageRequest != null)
          {
            localBatchedImageRequest.removeContainerAndCancelIfNecessary(this);
            if (localBatchedImageRequest.mContainers.size() == 0) {
              ImageLoader.this.mBatchedResponses.remove(this.mCacheKey);
            }
          }
        }
      }
    }
    
    public Bitmap getBitmap()
    {
      return this.mBitmap;
    }
    
    public String getRequestUrl()
    {
      return this.mRequestUrl;
    }
  }
  
  public static abstract interface ImageListener
    extends Response.ErrorListener
  {
    public abstract void onResponse(ImageLoader.ImageContainer paramImageContainer, boolean paramBoolean);
  }
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/com/android/volley/toolbox/ImageLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */