package com.android.vending.billing.util;

public class Base64DecoderException
  extends Exception
{
  private static final long serialVersionUID = 1L;
  
  public Base64DecoderException() {}
  
  public Base64DecoderException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /prj/BitcoinChecker/tools/dex-tools-2.1-SNAPSHOT/bc-signed-aligned-dex2jar.jar!/com/android/vending/billing/util/Base64DecoderException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */